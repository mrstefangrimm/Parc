# ParcLib

Arduino library which is part of the Parc software package. The library contains the domain model and shared code for 32u4 feathers. All Parc device projects are based on this library.

See also the [Parc Readme](https://github.com/mrstefangrimm/parc/) for a more detailed Readme.